package autotest.matrix;

public class Matrix {

	public static int[][] reshape(int[][] matrix, int r, int c){
		/*TODO*/
		/* Your code here */
		return matrix;
	}

	public static int[][] lowerTriangleMatrix(int[][] matrix){
		/*TODO*/
		/* Your code here */
		return matrix;
	}

	public static int[] convertToArray(int[][] matrix){
		/*TODO*/
		/* Your code here */
		return null;
	}

	public static int[] colMean(int[][] matrix){
		/*TODO*/
		/* Your code here */
		return null;
	}

}
